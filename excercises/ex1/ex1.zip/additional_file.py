#################################################################
# FILE : additional_file.py
# WRITER : Shai Feldman , shai.feldman , 332519636
# EXERCISE : intro2cs ex1 2025
#################################################################

def secret_function():
    print("My username is 'shai.feldman' and I found the string '5SqScQwD0Y9b' in the results file.")


if __name__ == '__main__':
    secret_function()
