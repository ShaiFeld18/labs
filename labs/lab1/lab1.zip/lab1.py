#############################################################
# FILE : lab1.py
# WRITER : Shai Feldman , shai.feldman , 332519636
# EXERCISE : intro2cs lab1 2025
# DESCRIPTION: A simple program that prints "Hello World!" to
# the standard output (screen).
#############################################################
print("Hello World!")
